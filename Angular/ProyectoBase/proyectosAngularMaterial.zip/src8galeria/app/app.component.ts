import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  anterior() {
    this.indiceImagenSeleccionada--;

    // if (this.indiceImagenSeleccionada == -1) {
    //   this.indiceImagenSeleccionada = 0;
    // }
    this.imagen = this.imagenes[this.indiceImagenSeleccionada];
  }
  siguiente() {
    this.indiceImagenSeleccionada++;

    // if (this.indiceImagenSeleccionada == this.imagenes.length) {
    //   this.indiceImagenSeleccionada = 0;
    // }
    this.imagen = this.imagenes[this.indiceImagenSeleccionada];
  }
  aumentar() {
    this.ancho += 10;
  }
  disminuir() {
    this.ancho -= 10;
  }
  stop() {
    clearInterval(this.temporizador);
  }

  play() {
    this.temporizador = setInterval(() => {
      this.siguiente;
    }, 100);
  }

  title = 'Angular P8';
  imagenes = [
    'https://randomuser.me/api/portraits/women/40.jpg',
    'https://randomuser.me/api/portraits/women/41.jpg',
    'https://randomuser.me/api/portraits/women/42.jpg',
    'https://randomuser.me/api/portraits/women/43.jpg',
    'https://randomuser.me/api/portraits/women/44.jpg',
    'https://randomuser.me/api/portraits/men/40.jpg',
    'https://randomuser.me/api/portraits/men/41.jpg',
    'https://randomuser.me/api/portraits/men/42.jpg',
    'https://randomuser.me/api/portraits/men/43.jpg',
    'https://randomuser.me/api/portraits/men/44.jpg',
  ];

  indiceImagenSeleccionada: number = 0;
  ancho: number = 0;
  imagen: string = '';
  auto: boolean = false;
  temporizador: NodeJS.Timeout | undefined;

  constructor() {
    this.indiceImagenSeleccionada = 0;
    this.ancho = 300;
    this.auto = false;
    this.imagen = this.imagenes[this.indiceImagenSeleccionada];
  }
}
