import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {

  constructor(){
    this.temporizador();
  }

  title = 'Angular Temporizador';

  horas: number = 0;
  minutos: number = 0;
  segundos: number = 0;
  milisegundos: number = 0;

  temp: NodeJS.Timeout | undefined;
  temporizador() {
    this.temp = setInterval(() => {
      this.horas = new Date().getHours();
      this.minutos = new Date().getMinutes();
      this.segundos = new Date().getSeconds();
      this.milisegundos = new Date().getMilliseconds();
    },100);
  }
}
