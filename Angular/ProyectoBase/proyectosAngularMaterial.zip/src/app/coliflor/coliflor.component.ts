import { Component } from '@angular/core';

@Component({
  selector: 'app-coliflor',
  templateUrl: './coliflor.component.html',
  styleUrls: ['./coliflor.component.css']
})
export class ColiflorComponent {

}
