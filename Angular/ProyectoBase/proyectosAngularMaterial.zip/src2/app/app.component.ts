import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  n:number=2;

  sumar(){
    this.n+=1;
  }

  restar(){
    this.n-=1;

  }
}

