import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Form1RoutingModule } from './form1-routing.module';

@NgModule({
  declarations: [],
  imports: [CommonModule, Form1RoutingModule],
})
export class Form1Module {}
