export class Usuario {
  idUsuario: number = 0;
  nombre: string = '';
  email: string = '';
  pwd: string = '';
  activo: number = 1;
}
