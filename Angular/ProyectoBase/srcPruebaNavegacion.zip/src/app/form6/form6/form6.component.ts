import { Component } from '@angular/core';

@Component({
  selector: 'app-form6',
  templateUrl: './form6.component.html',
  styleUrls: ['./form6.component.css']
})
export class Form6Component {
  title = 'Imagenes random';

}
