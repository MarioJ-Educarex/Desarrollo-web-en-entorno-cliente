import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Form2RoutingModule } from './form2-routing.module';


@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule,
    Form2RoutingModule
  ]
})
export class Form2Module { }
