import { Component } from '@angular/core';

@Component({
  selector: 'app-form7',
  templateUrl: './form7.component.html',
  styleUrls: ['./form7.component.css']
})
export class Form7Component {

}
