export class Alumno {
  cif!: string;
  nombre!: string;
  n1!: number;
  n2!: number;
  n3!: number;
}
