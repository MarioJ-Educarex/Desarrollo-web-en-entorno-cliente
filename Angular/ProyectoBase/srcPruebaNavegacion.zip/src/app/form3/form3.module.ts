import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Form3RoutingModule } from './form3-routing.module';

@NgModule({
  declarations: [],
  imports: [CommonModule, Form3RoutingModule],
})
export class Form3Module {}
