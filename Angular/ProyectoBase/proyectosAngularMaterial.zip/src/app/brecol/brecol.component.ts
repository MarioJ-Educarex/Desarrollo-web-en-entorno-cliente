import { Component } from '@angular/core';

@Component({
  selector: 'app-brecol',
  templateUrl: './brecol.component.html',
  styleUrls: ['./brecol.component.css']
})
export class BrecolComponent {

}
