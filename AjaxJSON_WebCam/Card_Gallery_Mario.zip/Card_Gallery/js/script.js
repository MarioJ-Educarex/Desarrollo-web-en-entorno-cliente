window.addEventListener("load", inicio);

let carruselIndicator = document.getElementsByClassName("carousel-indicators");
let carruselInner = document.getElementsByClassName("carousel-inner");

//let carruselIndicator = document.querySelector("ol class='carousel-indicators'");
//let fEquipos = document.querySelector("div class["row mt - 5"]");

function inicio() {

    mostrar();

}

function mostrar() {
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = cargar;
    function cargar() {
        if (this.readyState == 4 && this.status == 200) {
            //Al hacer parse nos devuelve un objeto
            var objeto = JSON.parse(this.responseText);

            objeto.forEach(recorrer);
            function recorrer(item, index) {
                //let list = document.createElement("li");
                // let col = document.createElement("td");
                if (index == 0) {
                    carruselIndicator.innerHTML =
                        "<li data-target='#carouselId' data-slide-to='" + index + "' class='active'>";
                    carruselInner.innerHTML = " <div class='carousel-item active'>" +
                        + "<div class='row'>" +
                        " <div class='col-md-3'>" +
                        "<a href='#''>" +
                        " <img src='" + item.imagen + "' alt='Image'style='max-width:100%;'>" +
                        "</a>" +
                        "<div class='carousel - caption d - none d - md - block'>" +
                        " <h3>Título 1</h3>" +
                        "<p>Descripción</p>" +
                        "</div>" +
                        " </div >" +
                        // " <div class='col - md - 3'>" +
                        // "<a href='#'>" +
                        // " <img src='" + item[index + 1].imagen + "' alt='Image' style='max-width:100%;'>" +
                        // "</a>" +
                        // "<div class='carousel - caption d - none d - md - block'>" +
                        // " <h3>Título 2</h3>" +
                        // "<p>Descripción</p>" +
                        // " </div>" +
                        // " </div>" +
                        // "<div class='col - md - 3'>" +
                        // "<a href='#'>" +
                        // "<img src='" + item[index + 2].imagen + "' alt='Image'  style='max-width:100%;'>" +
                        // " </a>" +
                        // " <div class='carousel - caption d - none d - md - block'>" +
                        // "<h3>Título 3</h3>" +
                        // " <p>Descripción</p>" +
                        // " </div>" +
                        // " </div>" +
                        // "<div class='col - md - 3'>" +
                        // " <a href='#'>" +
                        // " <img src='" + item[index + 3].imagen + "' alt='Image' style='max-width:100%;'>" +
                        // " </a>" +
                        // "<div class='carousel - caption d - none d - md - block'>" +
                        // "<h3>Título 4</h3>" +
                        // "<p>Descripción</p>" +
                        // "</div>" +
                        // "</div>" +
                        "</div>" +
                        "</div>";
                } else {
                    carruselIndicator.innerHTML =
                        "<li data-target='#carouselId' data-slide-to='" + index + "'>";
                    carruselInner.innerHTML = " <div class='carousel-item'>" +
                        + "<div class='row'>" +
                        " <div class='col-md-3'>" +
                        "<a href='#''>" +
                        " <img src='" + item.imagen + "' alt='Image'style='max-width:100%;'>" +
                        "</a>" +
                        "<div class='carousel - caption d - none d - md - block'>" +
                        " <h3>Título 1</h3>" +
                        "<p>Descripción</p>" +
                        "</div>" +
                        " </div >" +
                        // " <div class='col - md - 3'>" +
                        // "<a href='#'>" +
                        // " <img src='" + item[index + 1].imagen + "' alt='Image' style='max-width:100%;'>" +
                        // "</a>" +
                        // "<div class='carousel - caption d - none d - md - block'>" +
                        // " <h3>Título 2</h3>" +
                        // "<p>Descripción</p>" +
                        // " </div>" +
                        // " </div>" +
                        // "<div class='col - md - 3'>" +
                        // "<a href='#'>" +
                        // "<img src='" + item[index + 2].imagen + "' alt='Image'  style='max-width:100%;'>" +
                        // " </a>" +
                        // " <div class='carousel - caption d - none d - md - block'>" +
                        // "<h3>Título 3</h3>" +
                        // " <p>Descripción</p>" +
                        // " </div>" +
                        // " </div>" +
                        // "<div class='col - md - 3'>" +
                        // " <a href='#'>" +
                        // " <img src='" + item[index + 3].imagen + "' alt='Image' style='max-width:100%;'>" +
                        // " </a>" +
                        // "<div class='carousel - caption d - none d - md - block'>" +
                        // "<h3>Título 4</h3>" +
                        // "<p>Descripción</p>" +
                        // "</div>" +
                        // "</div>" +
                        "</div>" +
                        "</div>";
                }

                // cuerpoTabla.appendChild(fila);

            }

        }
    }
    xhr.open("GET", "http://moralo.atwebpages.com/ajaxListar/getTodoPersonal.php", true);
    xhr.send();

}
