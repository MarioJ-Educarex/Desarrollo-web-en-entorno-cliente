import { Component } from '@angular/core';

@Component({
  selector: 'app-romanesku',
  templateUrl: './romanesku.component.html',
  styleUrls: ['./romanesku.component.css']
})
export class RomaneskuComponent {

}
