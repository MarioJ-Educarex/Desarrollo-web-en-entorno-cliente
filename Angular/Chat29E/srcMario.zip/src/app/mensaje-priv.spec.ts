import { MensajePriv } from './mensaje-priv';

describe('MensajePriv', () => {
  it('should create an instance', () => {
    expect(new MensajePriv()).toBeTruthy();
  });
});
