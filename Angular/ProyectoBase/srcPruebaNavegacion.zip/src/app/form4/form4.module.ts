import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Form4RoutingModule } from './form4-routing.module';

@NgModule({
  declarations: [],
  imports: [CommonModule, Form4RoutingModule],
})
export class Form4Module {}
