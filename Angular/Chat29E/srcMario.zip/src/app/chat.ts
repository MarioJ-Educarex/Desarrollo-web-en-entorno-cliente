export class Chat {
  id: number = 0;
  usuario: string = '';
  fecha: string = '';
  mensaje: string = '';
}
